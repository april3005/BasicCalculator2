package com.example.basiccalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Intent intent = getIntent();

        ArrayList<Integer> numbers = intent.getIntegerArrayListExtra("numbers");
        ArrayList<String> operations = intent.getStringArrayListExtra("operations");



        Integer result = numbers.get(0);
        for (int i = 0; i < numbers.size() -1 ; i++) {
            switch (operations.get(i)){
                case "+":
                    result += numbers.get(i);
                    break;
                case "-":
                    result -= numbers.get(i + 1);
                    break;
                case "*":
                    result *= numbers.get(i + 1);
                    break;
                case "/":
                    result /= numbers.get(i + 1);
                    break;
            }

            Log.d("ololo", PrettyResult.convert(numbers, operations) + "=" + result.toString());

        }


    }
}
